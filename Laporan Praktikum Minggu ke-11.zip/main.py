# Ini Untuk Mengimpor sebuah modul matematika
import matematika

# Untuk Menghitung luas lingkaran menggunakan cara seperti ini : 
jari_jari = float(input("Masukkan jari-jari lingkaran: "))
luas_lingkaran = matematika.hitung_luas_lingkaran(jari_jari)
print(f"Luas lingkaran dengan jari-jari {jari_jari} adalah: {luas_lingkaran}")

# Untuk Menghitung luas persegi bisa menggunakan cara seperti ini :
sisi = float(input("Masukkan panjang sisi persegi: "))
luas_persegi = matematika.hitung_luas_persegi(sisi)
print(f"Luas persegi dengan sisi {sisi} adalah: {luas_persegi}")