PI = 3.14159

def hitung_luas_lingkaran(jari_jari):
    """Menghitung luas lingkaran berdasarkan jari-jari."""
    return PI * (jari_jari ** 2)

def hitung_luas_persegi(sisi):
    """Menghitung luas persegi berdasarkan panjang sisi."""
    return sisi ** 2

def hitung_luas_persegi_panjang(panjang, lebar):
    """Menghitung luas persegi panjang berdasarkan panjang dan lebar."""
    return panjang * lebar